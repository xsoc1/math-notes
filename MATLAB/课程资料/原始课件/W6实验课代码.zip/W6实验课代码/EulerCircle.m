% A = [0,1,2,2;1,0,1,1;2,1,0,0;2,1,0,0];
% A = [0,1,0,0,0;1,0,1,1,1;0,1,0,1,0;0,1,1,0,1;0,1,0,1,0];
A = [0,1,1,1,1;1,0,1,1,1;1,1,0,1,1;1,1,1,0,1;1,1,1,1,0];
Degree_vertices = sum(A);               %计算每个点的度
OE_Degree = mod(Degree_vertices,2);     %计算每个点度的的奇偶性
Num_OP = sum(OE_Degree);                %计算奇点个数
if(Num_OP == 0)
    fprintf('可以完成\n');
    S = 1,E = 1                         %无奇点则任意点开始，同一点结束
elseif(Num_OP == 2)
    fprintf('可以完成\n');
    temp = find(OE_Degree == 1);
    S = temp(1), E = temp(2)            %两奇点则其中一个开始，另一个结束
else
    fprintf('无法完成\n');				%奇点超过两个则无法完成
end
