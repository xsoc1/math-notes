syms t s f(t);
df=diff(f(t),t);
Ldy=laplace(df,t,s)  
isAlways(Ldy==s*laplace(f,t,s)-f(0))
