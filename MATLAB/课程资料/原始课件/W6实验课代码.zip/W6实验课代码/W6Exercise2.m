syms x y(x)
S1 = dsolve(diff(y(x))==y+x)
S2 = simplify(dsolve(diff(y(x))==y^2+x^2),100)