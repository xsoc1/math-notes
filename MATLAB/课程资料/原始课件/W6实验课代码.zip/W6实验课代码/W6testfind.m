n = 1000;
A = rand(n);			%生成随机样本构成的矩阵，共1000000个元素
AA = A;					%保护A的值不变

tic;ind = find(A>=0.5);toc;				%将大于等于0.5元素的下标获取并存在ind里

tic;B = A>=0.5;toc;						%仅判断并获取同型逻辑矩阵B，不获取下标

tic;A(ind) = -A(ind);toc;								%利用下标ind做寻访，效率更高
A = AA; tic;A(find(A>=0.5)) = - A(find(A>=0.5));toc;	%在等式里find两次浪费时间
A = AA;tic;A(A>=0.5) = - A(A>=0.5);toc;					%这个写法实战很常用，但效率也不高
A = AA;tic;A(B) = - A(B);toc;							%利用逻辑矩阵B做寻访不如下标ind好

n = 1000;
A = rand(n);
AA = A;
% 下面的例子将0.5改成了0.99，表示如果符合条件的样本只是少部分的话，
% 利用find函数拿到的下标ind做寻访效率会大大增加
tic;ind = find(A>=0.99);toc;
tic;B = A>=0.99;toc;
tic;A(ind) = -A(ind);toc;
A = AA;tic;A(find(A>=0.99)) = - A(find(A>=0.99));toc;
A = AA;tic;A(A>=0.99) = - A(A>=0.99);toc;
A = AA;tic;A(B) = - A(B);toc;